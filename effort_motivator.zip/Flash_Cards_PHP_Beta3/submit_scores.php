<?php
session_start();
$user = $_SESSION['user'];

$percent = $_REQUEST['percent'];
$average = $_REQUEST['final_average'];
$opperand = $_REQUEST['opperand'];

$con = mysql_connect("localhost","obesechi_hacka","hackathon123");
///$con = mysql_connect("localhost","","");
 if (!$con)
   {
   die('Could not connect: ' . mysql_error());
   }
	/*
	else//checking that connection is successful
	{
	echo nl2br("connection successful\n");//nl2br is used for html line breaks.
	}
	*/ 
mysql_select_db("obesechi_hacka", $con);//connecting to database

$sql = "UPDATE users
SET percent='$percent', average='$average', points='10*(.3*$average + .7*$percent)'
WHERE user='$user'";//creating the update to parameter

if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }
mysql_close($con);

header("Location: ./flash.php?table=$opperand");
?>