<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Flash Cards PHP</title>
<style type="text/css">
<!--
.style1 {font-size: 36px}
.style2 {
	font-size: 16px;
	color: #999999;
}
.style3 {color: #999999}
a:link {
	color: #00CCFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #993366;
}
a:hover {
	text-decoration: underline;
	color: #66FF00;
}
a:active {
	text-decoration: none;
	color: #FF00FF;
}
.style18 {	color: #0066FF;
	font-size: 16px;
}
-->
</style></head>

<body>
<div align="center">
  <p class="style1"><img src="images/logo.jpg" alt="PHP Flash Cards" width="383" height="59" /></p>

  <p class="style1">Please Select a Module:</p>
  <table width="200" border="0" cellspacing="2" cellpadding="2">
    <tr>
      <td><ul>
        <li><a href="flash.php?table=addition">Addition</a></li>
        <li><a href="flash.php?table=subtraction">Subtraction</a></li>
        <li><a href="flash.php?table=multiplication">Multiplication</a></li>
        <li><a href="flash.php?table=division">Division</a></li>
      </ul>      </td>
    </tr>
  </table>
  <hr />
  <table width="598" border="0" cellspacing="2" cellpadding="2">
</table>
</div>
<a href="../effort_motivator/index.php">I'm lost D:! TAKE ME HOME!</a>
</body>
</html>
