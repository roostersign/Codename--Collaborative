<?
session_start();

//connect to db
$con = mysql_connect("localhost","obesechi_hacka","hackathon123");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
  
mysql_select_db("obesechi_hacka", $con);//select db
  

$query_users = mysql_query("SELECT * FROM users");//selecttable

?>
<?php
//Print out array of students
///make it only students teachers have access to.
$query_users = mysql_query("SELECT * FROM users");//selecttable

//= Closed while ====================//

echo "<table border='1' align='center'>";
echo "<th>user</th>
<th>average</th>
<th>percentage right</th>
";
while($row_users = mysql_fetch_array($query_users))
{
//= Prints $r as array =================//
echo "<tr>";
echo "<td>" . $row_users['user'] . "</td>";
echo "<td>" . $row_users['average'] . "</td>";
echo "<td>" . $row_users['percent'] . "</td>";
echo "<td>" . $row_users['points'] . "</td>";
echo "</tr>";
}
echo "</table>";
mysql_close($server);  
?>