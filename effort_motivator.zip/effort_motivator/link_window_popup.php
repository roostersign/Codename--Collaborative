<html>
<head>
<script type="text/javascript">
// Popup window code
function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=510,width=700,left=10,top=10,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
}
</script>
</head>
<body>
<a href=JavaScript:newPopup("http://www.neopets.com/games/play_flash.phtml?va=&game_id=885&nc_referer=&age=0&hiscore=&sp=0&questionSet=&r=1723877&&width=700&height=510&quality=high")>Popup window</a>
<body>
</html>