<!DOCTYPE html>
<html>
<head>
<style type = "text/css">
body
{
font-family: Century Gothic, sans-serif;
background-color:#ffffcc;
}

#content {
  float: left;
  background-color: white;
  border: 3px solid gold;
  margin: 0;
  padding: 25px;
  width: 500px;
}

.inputs input{
border: 1px solid #397D02;

}

.selects select{
  border: 1px solid #397D02;

}

.button {
    border: 1px solid #397D02;
    background: #93DB70;
}

label {
    display: block;
    width: 70px;
    float: left;
    margin: 2px 4px 6px 4px;
    text-align: right;
}
br { clear: left; }

</style>
</head>
<body>
  <div id="content">



<form action="register_user.php" method="post"><h2>Registration</h2>
  <div class = "inputs">
  <div class = "selects">
  <label for="userid">ID</label>
  <input type="text" name="userid" id="userid" />
  <br />
  <label for="password">Password</label>
  <input type="password" name="password" id="password" />
	<select name="privilege">
	  <option value="1">teacher</option>
	  <option value="2">student</option>
	</select>
  <br />
  <input type="submit" name="submit" value="Submit" class="button"/>
</form>

<br />
<a href="authentication.php" style = "color: green;">Login as Existing User?</a>

</div>
</div>
</div>
</body>
</html>