<!DOCTYPE html>
<html>
<head>
<style type = "text/css">
body
{
font-family: Century Gothic, sans-serif;
background-color:#ffffcc;

}

#content {
  background-color: white;
  border: 3px solid gold;
  margin: 0;
  margin-left: auto;
  margin-right: auto;
  padding: 25px;
  width: 500px;
}

.inputs input{
border: 1px solid #397D02;

}

.selects select{
  border: 1px solid #397D02;

}

.button {
    border: 1px solid #397D02;
    background: #93DB70;
}

label {
    display: block;
    width: 70px;
    float: left;
    margin: 2px 4px 6px 4px;
    text-align: right;
}
br { clear: left; }

</style>
</head>
<body>
  <div id="content">

<h2>Sign in!</h2>



<form action="validate_user.php" method="post">
  <div class = "inputs">
  <div class = "selects">
  <label for="userid">ID</label>
  <input type="text" name="userid" id="userid" />
  <br />
  <label for="password">Password</label>
  <input type="password" name="password" id="password" />
	<select name="privilege">
	  <option value="1">teacher</option>
	  <option value="2">student</option>
	</select>
  <br />

  <input type="submit" name="submit" value="Submit" class = "button"/>

  </div>
</form>



<a href="registration.php" style = "color: green;">New User?  Click here!</a>

</div>
</div>
</body>
</html>