<!DOCTYPE html>
<html>
<head>
<style type = "text/css">
body
{
font-family: Century Gothic, sans-serif;
background-color:#ffffcc;
text-align: center
}

#content {
  background-color: white;
  border: 3px solid gold;
  margin: 0;
  margin-left: auto;
  margin-right: auto;
  padding: 25px;
  width: 550px;
}

</style>
</head>
<body>
  <div id="content">

<?php
?>
<html>
<head>
<h1>Games!</h1>
<script type="text/javascript">
// Popup window code
function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=510,width=700,left=10,top=10,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
}
</script>
</head>

<a href="../Flash_Cards_PHP_Beta3/index.php" target="_blank"><img src="math.jpg" width="200" height="200"></img></a>
<a href=JavaScript:newPopup("http://www.neopets.com/games/play_flash.phtml?va=&game_id=885&nc_referer=&age=0&hiscore=&sp=0&questionSet=&r=1723877&&width=700&height=510&quality=high")><img src="neopets_sheep_counter.png" width="300" height"100"></img></a>

<br />
<br />
<a href="index.php" style = "color: green; text-align: right;">Back to Home!</a>

</html>
</div>
</body>
</html>