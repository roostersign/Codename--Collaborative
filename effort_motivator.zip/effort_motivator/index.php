<!DOCTYPE html>
<html>
<head>
<style type = "text/css">
body
{
font-family: Century Gothic, sans-serif;
background-color:#ffffcc;
}

#content {
  background-color: white;
  border: 3px solid gold;
  margin: 0;
  margin-left: auto;
  margin-right: auto;
  padding: 25px;
  width: 500px;
}
</style>
</head>
<body>
  <div id="content">

<?php
session_start();///*now these few lines or something similar need to be added to every page. Alternatively link to every page with a handler in index.php and have index.php verify authentication. Don't include include this line when you want to logout
header("Cache-control: private");

if ($_SESSION["access"] != "granted")///if not logged in
{

  header("Location: ./authentication.php");///redirect to login url
  }
else 
{
	require_once './test_horizontal_menu.php';
	echo "Welcome " . $_SESSION['user'] . " ! <br />";
	echo "<a href='logout.php' style = 'color: green;'>logout</a><br />";
}
  
//else logged in
//get some variables
$user = $_POST["userid"];
$pass = sha1($_POST["password"]);///change sha1 to whatever encryption is used to store data in the field
$privilege = $_POST["privilege"];//teacher or student
?>


</div>
</body>
</html>
