<!DOCTYPE html>
<html>
<head>
<style type = "text/css">
body
{
font-family: Century Gothic, sans-serif;
background-color:#ffffcc;

}

#content {
  background-color: white;
  border: 3px solid gold;
  margin: 0;
  margin-left: auto;
  margin-right: auto;
  padding: 25px;
  width: 500px;
}

</style>
</head>
<body>
  <div id="content">
<?
session_start();

//connect to db
$con = mysql_connect("localhost","obesechi_hacka","hackathon123");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
  
mysql_select_db("obesechi_hacka", $con);//select db
  

$query_users = mysql_query("SELECT * FROM users");//selecttable

//allow parents to add students to watch list
?>
<html>
 <head>
 </head>
 <body>
 <form method="post" action="/add_incentive.php"><title>Add an incentive to a game</title> <!--I think because the action is a php file, "post" is not needed-->
 <table bgcolor=#ffffff align=center bordercolor=#ddd> 

 <!-- Will determine who gets the incentive. Selected by user from a dropdown list depending on their name. -->
<tr><td>This Week's Incentive:</td>
<td><input name="incentives" type="text" align=center></input></td></tr>
<td>given to:</td>
<td><select name="students"> 
<?php while($row_users = mysql_fetch_array($query_users))
{
	if ($row_users['privilege'] == 2)//if student, place in dropdown
	{
	echo "<option value=" . $row_users['user'] . '>' . $row_users['user'] . '</option>';
	}
}
?>
 </select><td>
</table></form></body></html>

  
<?php
//Print out array of students
///make it only students teachers have access to.
$query_users = mysql_query("SELECT * FROM users");//selecttable

//= Closed while ====================//

echo "<table align='center' bordercolor=#ddd>";
echo "<th>all users</th>
<th>average</th>
<th>percentage right</th>
<th>coins</th>
";
while($row_users = mysql_fetch_array($query_users))
{
//= Prints $r as array =================//
echo "<tr>";
echo "<td>" . $row_users['user'] . "</td>";
echo "<td>" . $row_users['average'] . "</td>";
echo "<td>" . $row_users['percent'] . "</td>";
echo "<td>" . $row_users['points'] . "</td>";
echo "</tr>";
}
echo "</table>";
mysql_close($server);  
?>

<a href="index.php" style = "color: green;">Back to Home!</a>
</div>
</body>
</html>