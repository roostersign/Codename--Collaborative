<?php
/* get the incoming ID and password hash */
$user = $_POST["userid"];
$pass = sha1($_POST["password"]);///change sha1 to whatever encryption is used to store data in the field
$privilege = $_POST["privilege"];//teacher or student


/* establish a connection with the database */
$server = mysql_connect("localhost", "obesechi_hacka",
          "hackathon123");///change the server name, username, and password to the real ones
if (!$server) die(mysql_error());
mysql_select_db("obesechi_hacka");///Change the word users to the real dbs

/* SQL statement to query the database */
/* query the database */
$result = mysql_query("SELECT * FROM users WHERE user = '$user'
         AND password = '$pass'");

/* Allow access if a matching record was found, else deny access. */
if ($row = mysql_fetch_row($result)) {
  session_start();
  $value = 'something from somewhere';
  setcookie("stupid_cookie", $value, time()+3600, '../', "www.obesechickenapps.com");
  
  $id = $row['0'];//id of user logging in
  header("Cache-control: private");
  $_SESSION['id'] = "$id";//id of user
  $_SESSION["access"] = "granted";
  $_SESSION["user"] = "$user";//username of logged in user
  $_SESSION["privilege"] = "$privilege";//privilege of user
  
  header("Location: ./index.php");///this is the page you go to if you access correctly
} else
  /* access denied &#8211; redirect back to login */
  header("Location: ./authentication.php");///you go here if you don't access
mysql_close($server);  
?>