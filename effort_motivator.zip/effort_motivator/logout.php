<?php
session_unset();//delete data of session and ID
session_start();
session_destroy();//get rid of session altogether
setcookie ("stupid_cookie", "", time() - 3600, '../', "www.obesechickenapps.com");//get rid of cookie browser
setcookie ("4af3a2dfc62da436624a257d166976c1", "", time() - 3600, '../', "www.obesechickenapps.com");//get rid of cookie browser
setcookie ("PHPSESSID", "", time() - 3600, '../', "www.obesechickenapps.com");//get rid of cookie browser

header("Location: ./authentication.php");
?>