<!DOCTYPE html>
<html>
<head>
<style type = "text/css">

body
{
font-family: Century Gothic, sans-serif;
background-color:#ffffcc;
text-align: center;
}

</style>
</head>


<?php
/* get the incoming ID and password hash */
$user = $_POST["userid"];
$pass = sha1($_POST["password"]);///change sha1 to whatever encryption is used to store data in the field
$privilege = $_POST["privilege"];//teacher or student

/* establish a connection with the database */
$server = mysql_connect("localhost", "obesechi_hacka",
          "hackathon123");///change the server name, username, and password to the real ones
if (!$server) die(mysql_error());
mysql_select_db("obesechi_hacka");///Change the word users to the real dbs

/* SQL statement to query the database */
$sql="INSERT INTO users (user, password, privilege) 
VALUES('$user', '$pass', '$privilege')";//creating the insert to parameter

if (!mysql_query($sql,$server))
  {
  die('Error: ' . mysql_error());
  }
  
mysql_close($server);  
?>

<body>
<p>Success!</p>
<a href="authentication.php" style = "color: #74b200;">Back to Login?</a>
</body>
</html>